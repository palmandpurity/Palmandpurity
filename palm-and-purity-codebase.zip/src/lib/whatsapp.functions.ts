import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Sends a WhatsApp text message via the Meta Cloud API.
 * Credentials are read from process.env inside the handler (server-only).
 *
 * Required env vars:
 *  - WHATSAPP_ACCESS_TOKEN      Meta System User permanent access token
 *  - WHATSAPP_PHONE_NUMBER_ID   The WhatsApp Business phone number ID
 */
export const sendWhatsAppMessage = createServerFn({ method: "POST" })
  .inputValidator((data) =>
    z
      .object({
        to: z
          .string()
          .regex(/^\d{8,15}$/, "Recipient must be digits only with country code"),
        body: z.string().min(1).max(4000),
      })
      .parse(data),
  )
  .handler(async ({ data }) => {
    const token = process.env["WHATSAPP_ACCESS_TOKEN"];
    const phoneNumberId = process.env["WHATSAPP_PHONE_NUMBER_ID"];

    if (!token || !phoneNumberId) {
      throw new Error("WhatsApp credentials are not configured.");
    }

    const response = await fetch(
      `https://graph.facebook.com/v20.0/${phoneNumberId}/messages`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          recipient_type: "individual",
          to: data.to,
          type: "text",
          text: { body: data.body },
        }),
      },
    );

    if (!response.ok) {
      const errorBody = await response.text();
      console.error(
        `WhatsApp send failed [${response.status}]: ${errorBody}`,
      );
      throw new Error(
        `WhatsApp send failed [${response.status}]: ${errorBody}`,
      );
    }

    return await response.json();
  });

/**
 * Forwards a contact form submission to the team's WhatsApp number.
 * The recipient is read from WHATSAPP_RECIPIENT_NUMBER (server-only) so the
 * client never controls the destination.
 *
 * Required env vars:
 *  - WHATSAPP_ACCESS_TOKEN
 *  - WHATSAPP_PHONE_NUMBER_ID
 *  - WHATSAPP_RECIPIENT_NUMBER   Team number to notify (digits, with country code)
 */
export const forwardContactToWhatsApp = createServerFn({ method: "POST" })
  .inputValidator((data) =>
    z
      .object({
        fullName: z.string().trim().min(1).max(200),
        email: z.string().trim().email().max(254),
        phone: z.string().trim().max(50).optional().or(z.literal("")),
        company: z.string().trim().max(200).optional().or(z.literal("")),
        subject: z.string().trim().min(1).max(200),
        message: z.string().trim().min(1).max(2000),
      })
      .parse(data),
  )
  .handler(async ({ data }) => {
    const recipient = process.env["WHATSAPP_RECIPIENT_NUMBER"];

    if (!recipient) {
      throw new Error("WHATSAPP_RECIPIENT_NUMBER is not configured.");
    }

    const body = [
      `*New Contact Form Submission*`,
      ``,
      `*Name:* ${data.fullName}`,
      `*Email:* ${data.email}`,
      data.phone ? `*Phone:* ${data.phone}` : null,
      data.company ? `*Company:* ${data.company}` : null,
      `*Subject:* ${data.subject}`,
      ``,
      data.message,
    ]
      .filter(Boolean)
      .join("\n");

    const response = await fetch(
      `https://graph.facebook.com/v20.0/${process.env["WHATSAPP_PHONE_NUMBER_ID"]}/messages`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env["WHATSAPP_ACCESS_TOKEN"]}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          recipient_type: "individual",
          to: recipient,
          type: "text",
          text: { body },
        }),
      },
    );

    if (!response.ok) {
      const errorBody = await response.text();
      console.error(
        `WhatsApp contact forward failed [${response.status}]: ${errorBody}`,
      );
      throw new Error(
        `WhatsApp contact forward failed [${response.status}]: ${errorBody}`,
      );
    }

    return await response.json();
  });

