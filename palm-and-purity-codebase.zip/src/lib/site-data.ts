import farmTihun from "@/assets/farm-tihun.jpg";
import farmBo from "@/assets/farm-bo.jpg";
import farmMasiaka from "@/assets/farm-masiaka.jpg";
import catCrops from "@/assets/cat-crops.jpg";
import catFruits from "@/assets/cat-fruits.jpg";
import catLivestock from "@/assets/cat-livestock.jpg";
import catAquaculture from "@/assets/cat-aquaculture.jpg";
import catApiculture from "@/assets/cat-apiculture.jpg";
import people from "@/assets/people.jpg";
import machinery from "@/assets/machinery.jpg";
import poultry from "@/assets/poultry.jpg";
import landscape from "@/assets/landscape.jpg";
import sustainability from "@/assets/sustainability.jpg";
import heroPalm from "@/assets/hero-palm.jpg";
import aboutFarm from "@/assets/about-farm.jpg";

export const images = {
  heroPalm,
  aboutFarm,
  sustainability,
  landscape,
  people,
  machinery,
  poultry,
  farmTihun,
  farmBo,
  farmMasiaka,
};

export const farms = [
  {
    slug: "tihun",
    name: "Tihun Farm",
    image: farmTihun,
    description:
      "A diversified agricultural operation combining mixed crops, rice, coconut, fruits and aquaculture, with future potential for palm kernel processing.",
    activities: [
      "Mixed crops",
      "Rice",
      "Coconut",
      "Fruits",
      "Aquaculture",
      "Future palm kernel processing",
    ],
  },
  {
    slug: "bo",
    name: "Bo Farm",
    image: farmBo,
    description:
      "A commercial agricultural operation focused on the development of a productive cashew plantation.",
    activities: ["Commercial cashew plantation"],
  },
  {
    slug: "masiaka",
    name: "Masiaka Farm",
    image: farmMasiaka,
    description:
      "A diversified farm combining livestock, poultry, aquaculture and beekeeping.",
    activities: ["Livestock", "Poultry", "Aquaculture", "Beekeeping"],
  },
];

export const portfolio = [
  {
    name: "Commercial Crops",
    image: catCrops,
    description:
      "Rice, cashew and other commercial agricultural products grown for local and regional markets.",
  },
  {
    name: "Fruits & Coconut",
    image: catFruits,
    description:
      "Tropical fruit and coconut production suited to Sierra Leone's climate and soils.",
  },
  {
    name: "Livestock",
    image: catLivestock,
    description:
      "Cattle, goats and poultry managed for productivity, animal health and steady supply.",
  },
  {
    name: "Aquaculture",
    image: catAquaculture,
    description:
      "Modern fish farming and water-based production integrated into our farm systems.",
  },
  {
    name: "Apiculture",
    image: catApiculture,
    description:
      "Beekeeping and honey production that support pollination and farm biodiversity.",
  },
];

export const sustainabilityPillars = [
  {
    name: "Circular Farming",
    description:
      "Promote efficient use of agricultural resources and minimise waste across our farms.",
  },
  {
    name: "Water Management",
    description:
      "Use responsible water management practices to support agricultural production.",
  },
  {
    name: "Pollination",
    description:
      "Support healthy ecosystems and natural pollination through beekeeping and biodiversity.",
  },
  {
    name: "Organic Fertilizer",
    description:
      "Encourage the use of organic agricultural inputs and responsible soil management.",
  },
  {
    name: "Climate-Smart Agriculture",
    description:
      "Adopt agricultural practices designed to improve resilience and sustainable productivity.",
  },
];

export const investmentAreas = [
  {
    name: "Diversified Operations",
    description: "Multiple agricultural activities across different locations.",
  },
  {
    name: "Value Addition",
    description: "Develop opportunities to process agricultural products locally.",
  },
  {
    name: "Processing",
    description:
      "Build future capacity for agricultural processing and production.",
  },
  {
    name: "Export Potential",
    description:
      "Develop products and markets with potential for regional and international expansion.",
  },
];

export const reasons = [
  {
    name: "Diversified Agriculture",
    description: "Our farms operate across multiple agricultural sectors.",
  },
  {
    name: "Strategic Locations",
    description: "Operations are distributed across Tihun, Bo and Masiaka.",
  },
  {
    name: "Sustainable Practices",
    description:
      "Environmental responsibility is integrated into our farming approach.",
  },
  {
    name: "Value Addition",
    description:
      "We aim to move beyond raw production toward processing and greater agricultural value.",
  },
  {
    name: "Growth Potential",
    description:
      "Our operations provide opportunities for expansion and long-term development.",
  },
  {
    name: "Sierra Leone Focus",
    description:
      "We are committed to contributing to Sierra Leone's agricultural economy.",
  },
];

export const gallery = [
  { image: farmTihun, category: "Farms", alt: "Mixed crop and coconut farm at Tihun" },
  { image: catCrops, category: "Crops", alt: "Green rice field ready for harvest" },
  { image: catLivestock, category: "Livestock", alt: "Cattle grazing on open pasture" },
  { image: catAquaculture, category: "Aquaculture", alt: "Fish pond on a tropical farm" },
  { image: catApiculture, category: "Beekeeping", alt: "Honeybees on a hive frame" },
  { image: people, category: "People & Agriculture", alt: "Farmers holding fresh harvested produce" },
  { image: landscape, category: "Sierra Leone Landscapes", alt: "Wide green Sierra Leone landscape" },
  { image: farmBo, category: "Farms", alt: "Commercial cashew plantation in Bo" },
  { image: poultry, category: "Livestock", alt: "Free-range chickens in a modern poultry house" },
  { image: catFruits, category: "Crops", alt: "Coconuts and tropical fruit" },
  { image: machinery, category: "People & Agriculture", alt: "Tractor working a green field" },
  { image: farmMasiaka, category: "Farms", alt: "Diversified livestock and fish farm at Masiaka" },
];

export const galleryCategories = [
  "All",
  "Farms",
  "Crops",
  "Livestock",
  "Aquaculture",
  "Beekeeping",
  "People & Agriculture",
  "Sierra Leone Landscapes",
];

export const contactDetails = {
  company: "Palm & Purity",
  country: "Sierra Leone",
  email: "info@palmandpurity.com",
  phone: "+232 73 391 309",
  location: "Sierra Leone",
};