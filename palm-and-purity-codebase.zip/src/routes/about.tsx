import { createFileRoute } from "@tanstack/react-router";
import { Compass, Target } from "lucide-react";
import { PageHero } from "@/components/section";
import { Reveal } from "@/components/reveal";
import { images } from "@/lib/site-data";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Palm & Purity — Integrated Sierra Leone Agribusiness" },
      {
        name: "description",
        content:
          "Palm & Purity combines crop production, livestock, aquaculture and apiculture with value addition and processing across Sierra Leone.",
      },
      { property: "og:title", content: "About Palm & Purity" },
      {
        property: "og:description",
        content:
          "An integrated agribusiness committed to food security, employment and sustainable agriculture in Sierra Leone.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About Us"
        title="About Palm & Purity"
        intro="An integrated agribusiness built around diversified agricultural operations in Sierra Leone."
        image={images.aboutFarm}
      />

      <section className="mx-auto grid max-w-6xl items-center gap-14 px-6 py-24 lg:grid-cols-2">
        <Reveal>
          <div className="overflow-hidden rounded-3xl shadow-lift">
            <img
              src={images.farmTihun}
              alt="Lush mixed crop and coconut farm in Sierra Leone"
              width={1200}
              height={900}
              loading="lazy"
              className="h-full w-full object-cover"
            />
          </div>
        </Reveal>
        <Reveal delay={120}>
          <p className="eyebrow text-leaf">Who we are</p>
          <h2 className="mt-4 text-3xl font-semibold text-forest-deep sm:text-4xl">
            Diversified by design
          </h2>
          <p className="mt-5 text-base leading-relaxed text-muted-foreground">
            Palm &amp; Purity is an integrated agribusiness built around
            diversified agricultural operations in Sierra Leone.
          </p>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground">
            Our approach combines crop production, livestock, aquaculture and
            apiculture while creating opportunities for value addition,
            processing and future expansion.
          </p>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground">
            We are committed to developing productive farms that contribute to
            food security, employment, sustainable agriculture and economic
            growth.
          </p>
        </Reveal>
      </section>

      <section className="bg-secondary/50 py-24">
        <div className="mx-auto grid max-w-5xl gap-6 px-6 sm:grid-cols-2">
          <Reveal>
            <div className="h-full rounded-3xl bg-card p-9 shadow-soft">
              <Target className="h-7 w-7 text-leaf" />
              <h3 className="mt-5 text-xl font-semibold text-forest-deep">
                Our Vision
              </h3>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                To contribute to a stronger and more sustainable agricultural
                future for Sierra Leone.
              </p>
            </div>
          </Reveal>
          <Reveal delay={120}>
            <div className="h-full rounded-3xl bg-card p-9 shadow-soft">
              <Compass className="h-7 w-7 text-leaf" />
              <h3 className="mt-5 text-xl font-semibold text-forest-deep">
                Our Approach
              </h3>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                Diversification, sustainability, productivity, innovation and
                value addition.
              </p>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}