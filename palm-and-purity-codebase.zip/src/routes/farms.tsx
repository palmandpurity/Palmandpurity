import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check } from "lucide-react";
import { PageHero } from "@/components/section";
import { Reveal } from "@/components/reveal";
import { farms, images } from "@/lib/site-data";

export const Route = createFileRoute("/farms")({
  head: () => ({
    meta: [
      { title: "Our Farms — Tihun, Bo & Masiaka | Palm & Purity" },
      {
        name: "description",
        content:
          "Explore Palm & Purity's three Sierra Leone farms: mixed crops and aquaculture in Tihun, cashew in Bo, and livestock, poultry and beekeeping in Masiaka.",
      },
      { property: "og:title", content: "Our Farms | Palm & Purity" },
      {
        property: "og:description",
        content:
          "Three complementary farms across Tihun, Bo and Masiaka forming a diversified agricultural portfolio.",
      },
    ],
  }),
  component: FarmsPage,
});

function FarmsPage() {
  return (
    <>
      <PageHero
        eyebrow="Our Farms"
        title="Three locations, one diversified portfolio"
        intro="Our farms in Tihun, Bo and Masiaka combine crops, aquaculture, livestock and apiculture into a resilient agricultural model."
        image={images.farmMasiaka}
      />

      <section className="mx-auto max-w-6xl space-y-16 px-6 py-24">
        {farms.map((farm, i) => (
          <Reveal key={farm.slug} as="article">
            <div
              className={`grid items-center gap-12 lg:grid-cols-2 ${
                i % 2 === 1 ? "lg:[&>div:first-child]:order-2" : ""
              }`}
            >
              <div className="overflow-hidden rounded-3xl shadow-lift">
                <img
                  src={farm.image}
                  alt={farm.name}
                  width={1200}
                  height={900}
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </div>
              <div>
                <p className="eyebrow text-leaf">Sierra Leone</p>
                <h2 className="mt-4 text-3xl font-semibold text-forest-deep sm:text-4xl">
                  {farm.name}
                </h2>
                <p className="mt-5 text-base leading-relaxed text-muted-foreground">
                  {farm.description}
                </p>
                <ul className="mt-7 grid gap-3 sm:grid-cols-2">
                  {farm.activities.map((activity) => (
                    <li
                      key={activity}
                      className="flex items-start gap-2.5 rounded-2xl bg-secondary/70 px-4 py-3 text-sm font-medium text-forest-deep"
                    >
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-leaf" />
                      {activity}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Reveal>
        ))}

        <Reveal className="text-center">
          <Link
            to="/agriculture"
            className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-soft transition-transform duration-200 hover:-translate-y-0.5"
          >
            Explore Our Agricultural Portfolio <ArrowRight className="h-4 w-4" />
          </Link>
        </Reveal>
      </section>
    </>
  );
}