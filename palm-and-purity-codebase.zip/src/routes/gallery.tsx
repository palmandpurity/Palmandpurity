import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/section";
import { Reveal } from "@/components/reveal";
import { gallery, galleryCategories, images } from "@/lib/site-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Farms, Crops & Landscapes | Palm & Purity" },
      {
        name: "description",
        content:
          "A visual tour of Palm & Purity: farms, crops, livestock, aquaculture, beekeeping, people and Sierra Leone landscapes.",
      },
      { property: "og:title", content: "Gallery | Palm & Purity" },
      {
        property: "og:description",
        content:
          "Photography from our farms across Tihun, Bo and Masiaka in Sierra Leone.",
      },
    ],
  }),
  component: GalleryPage,
});

function GalleryPage() {
  const [active, setActive] = useState("All");
  const items =
    active === "All" ? gallery : gallery.filter((i) => i.category === active);

  return (
    <>
      <PageHero
        eyebrow="Gallery"
        title="Agriculture in picture"
        intro="Farms, crops, livestock, aquaculture, beekeeping, people and the landscapes of Sierra Leone."
        image={images.landscape}
      />

      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="flex flex-wrap justify-center gap-2">
          {galleryCategories.map((category) => (
            <button
              key={category}
              type="button"
              onClick={() => setActive(category)}
              className={cn(
                "rounded-full border px-4 py-2 text-sm font-medium transition-colors",
                active === category
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card text-muted-foreground hover:border-leaf hover:text-forest",
              )}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="mt-12 columns-1 gap-6 sm:columns-2 lg:columns-3 [&>*]:mb-6">
          {items.map((item, i) => (
            <Reveal key={`${item.category}-${i}`} delay={(i % 3) * 90}>
              <figure className="group relative overflow-hidden rounded-3xl shadow-soft">
                <img
                  src={item.image}
                  alt={item.alt}
                  width={1200}
                  height={900}
                  loading="lazy"
                  className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <figcaption className="absolute inset-x-0 bottom-0 translate-y-2 bg-gradient-to-t from-forest-deep/90 to-transparent p-5 text-sm font-medium text-primary-foreground opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                  {item.category}
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}