import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Building2, Mail, MapPin, MessageCircle, Phone, Send } from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { PageHero } from "@/components/section";
import { Reveal } from "@/components/reveal";
import { forwardContactToWhatsApp } from "@/lib/whatsapp.functions";
import { contactDetails, images } from "@/lib/site-data";

const whatsappNumber = contactDetails.phone.replace(/\D/g, "");
const whatsappUrl = `https://wa.me/${whatsappNumber}`;

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Palm & Purity — Let's Grow Together" },
      {
        name: "description",
        content:
          "Contact Palm & Purity for agricultural partnerships, investment and business opportunities in Sierra Leone.",
      },
      { property: "og:title", content: "Contact Palm & Purity" },
      {
        property: "og:description",
        content:
          "Reach out about agricultural partnerships, investment or business opportunities in Sierra Leone.",
      },
    ],
  }),
  component: ContactPage,
});

const fields = [
  { name: "fullName", label: "Full Name", type: "text", required: true },
  { name: "email", label: "Email Address", type: "email", required: true },
  { name: "phone", label: "Phone Number", type: "tel", required: false },
  { name: "company", label: "Company / Organization", type: "text", required: false },
  { name: "subject", label: "Subject", type: "text", required: true },
] as const;

function ContactPage() {
  const [sending, setSending] = useState(false);
  const sendContact = useServerFn(forwardContactToWhatsApp);

  return (
    <>
      <PageHero
        eyebrow="Contact"
        title="Let's Grow Together"
        intro="Whether you are interested in agricultural partnerships, investment, business opportunities or learning more about Palm & Purity, we would be happy to connect."
        image={images.people}
      />

      <section className="mx-auto grid max-w-6xl gap-12 px-6 py-24 lg:grid-cols-[1.4fr_1fr]">
        <Reveal>
          <form
            className="rounded-3xl border border-border/70 bg-card p-8 shadow-soft sm:p-10"
            onSubmit={async (event) => {
              event.preventDefault();
              const form = event.currentTarget;
              const data = new FormData(form);
              const payload = {
                fullName: String(data.get("fullName") ?? ""),
                email: String(data.get("email") ?? ""),
                phone: String(data.get("phone") ?? ""),
                company: String(data.get("company") ?? ""),
                subject: String(data.get("subject") ?? ""),
                message: String(data.get("message") ?? ""),
              };
              setSending(true);
              try {
                await sendContact({ data: payload });
                form.reset();
                toast.success("Thank you — your message has been sent.", {
                  description: "A member of our team will be in touch shortly.",
                });
              } catch (err) {
                console.error(err);
                toast.error("Sorry, your message could not be sent.", {
                  description:
                    "Please try again or reach us directly on WhatsApp.",
                });
              } finally {
                setSending(false);
              }
            }}
          >
            <h2 className="text-2xl font-semibold text-forest-deep">
              Send us a message
            </h2>
            <div className="mt-8 grid gap-5 sm:grid-cols-2">
              {fields.map((field) => (
                <div
                  key={field.name}
                  className={field.name === "subject" ? "sm:col-span-2" : ""}
                >
                  <label
                    htmlFor={field.name}
                    className="text-sm font-medium text-forest-deep"
                  >
                    {field.label}
                    {field.required ? (
                      <span className="text-destructive"> *</span>
                    ) : null}
                  </label>
                  <input
                    id={field.name}
                    name={field.name}
                    type={field.type}
                    required={field.required}
                    maxLength={200}
                    className="mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-colors focus:border-leaf focus:ring-2 focus:ring-ring/30"
                  />
                </div>
              ))}
              <div className="sm:col-span-2">
                <label
                  htmlFor="message"
                  className="text-sm font-medium text-forest-deep"
                >
                  Message<span className="text-destructive"> *</span>
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={5}
                  required
                  maxLength={2000}
                  className="mt-2 w-full resize-y rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-colors focus:border-leaf focus:ring-2 focus:ring-ring/30"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={sending}
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-soft transition-transform duration-200 hover:-translate-y-0.5 disabled:opacity-70"
            >
              <Send className="h-4 w-4" />
              {sending ? "Sending…" : "Send Message"}
            </button>
          </form>
        </Reveal>

        <Reveal delay={120} className="space-y-5">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-4 rounded-3xl border border-[#25D366]/40 bg-[#25D366]/5 p-7 shadow-soft transition-transform duration-200 hover:-translate-y-0.5"
          >
            <span className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#25D366] text-white">
              <MessageCircle className="h-6 w-6" />
            </span>
            <span className="min-w-0">
              <h3 className="text-base font-semibold text-forest-deep">
                Chat on WhatsApp
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Reach us instantly at {contactDetails.phone}
              </p>
            </span>
          </a>
          {[
            {
              Icon: Building2,
              title: contactDetails.company,
              value: contactDetails.country,
            },
            {
              Icon: Mail,
              title: "Email",
              value: contactDetails.email,
              href: `mailto:${contactDetails.email}`,
            },
            {
              Icon: Phone,
              title: "Phone",
              value: contactDetails.phone,
              href: `tel:${contactDetails.phone.replace(/\s/g, "")}`,
            },
            { Icon: MapPin, title: "Location", value: contactDetails.location },
          ].map(({ Icon, title, value, href }) => (
            <div
              key={title}
              className="rounded-3xl border border-border/70 bg-card p-7 shadow-soft"
            >
              <span className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-secondary">
                <Icon className="h-5 w-5 text-leaf" />
              </span>
              <h3 className="mt-4 text-base font-semibold text-forest-deep">
                {title}
              </h3>
              {href ? (
                <a
                  href={href}
                  className="mt-1 block break-all text-sm text-muted-foreground transition-colors hover:text-forest"
                >
                  {value}
                </a>
              ) : (
                <p className="mt-1 text-sm text-muted-foreground">{value}</p>
              )}
            </div>
          ))}
        </Reveal>
      </section>
    </>
  );
}