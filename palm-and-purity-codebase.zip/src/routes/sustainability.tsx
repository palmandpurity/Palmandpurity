import { createFileRoute } from "@tanstack/react-router";
import { Droplets, Flower2, Leaf, Recycle, Sun } from "lucide-react";
import { PageHero } from "@/components/section";
import { Reveal } from "@/components/reveal";
import { sustainabilityPillars, images } from "@/lib/site-data";

const icons = [Recycle, Droplets, Flower2, Leaf, Sun];

export const Route = createFileRoute("/sustainability")({
  head: () => ({
    meta: [
      { title: "Sustainability — Farming Responsibly | Palm & Purity" },
      {
        name: "description",
        content:
          "Circular farming, water management, pollination, organic inputs and climate-smart agriculture at Palm & Purity in Sierra Leone.",
      },
      { property: "og:title", content: "Sustainability | Palm & Purity" },
      {
        property: "og:description",
        content:
          "Agricultural practices that protect natural resources while improving productivity and long-term value.",
      },
    ],
  }),
  component: SustainabilityPage,
});

function SustainabilityPage() {
  return (
    <>
      <PageHero
        eyebrow="Sustainability"
        title="Farming Responsibly. Growing Sustainably."
        intro="Palm & Purity is committed to agricultural practices that protect natural resources while improving productivity and creating long-term value."
        image={images.sustainability}
      />

      <section className="mx-auto max-w-6xl px-6 py-24">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {sustainabilityPillars.map((pillar, i) => {
            const Icon = icons[i % icons.length]!;
            return (
              <Reveal key={pillar.name} delay={i * 90}>
                <div className="h-full rounded-3xl border border-border/70 bg-card p-8 shadow-soft transition-transform duration-300 hover:-translate-y-1.5">
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary">
                    <Icon className="h-5 w-5 text-leaf" />
                  </span>
                  <h2 className="mt-5 text-xl font-semibold text-forest-deep">
                    {pillar.name}
                  </h2>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {pillar.description}
                  </p>
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      <section className="relative isolate overflow-hidden">
        <img
          src={images.landscape}
          alt=""
          aria-hidden="true"
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-forest-deep/85" />
        <div className="relative mx-auto max-w-4xl px-6 py-24 text-center">
          <Reveal>
            <h2 className="text-3xl font-semibold text-primary-foreground sm:text-4xl">
              Sustainability is a productivity strategy
            </h2>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-primary-foreground/80">
              Healthy soils, managed water, active pollinators and resilient
              cropping systems are what make long-term agricultural returns
              possible.
            </p>
          </Reveal>
        </div>
      </section>
    </>
  );
}