import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Factory, Globe2, Layers, PackageCheck } from "lucide-react";
import { PageHero, SectionHeading } from "@/components/section";
import { Reveal } from "@/components/reveal";
import { investmentAreas, reasons, images } from "@/lib/site-data";

const icons = [Layers, PackageCheck, Factory, Globe2];

export const Route = createFileRoute("/investment")({
  head: () => ({
    meta: [
      { title: "Investment & Growth — Agricultural Opportunities | Palm & Purity" },
      {
        name: "description",
        content:
          "Palm & Purity offers agricultural investment opportunities in value addition, processing, market development and export from Sierra Leone.",
      },
      { property: "og:title", content: "Investing in Agricultural Growth" },
      {
        property: "og:description",
        content:
          "A diversified agribusiness model built for value addition, processing and export potential.",
      },
    ],
  }),
  component: InvestmentPage,
});

function InvestmentPage() {
  return (
    <>
      <PageHero
        eyebrow="Investment"
        title="Investing in Agricultural Growth"
        intro="Palm & Purity's diversified agricultural model creates opportunities for value addition, processing, market development and long-term agricultural investment."
        image={images.people}
      />

      <section className="mx-auto max-w-6xl px-6 py-24">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {investmentAreas.map((area, i) => {
            const Icon = icons[i % icons.length]!;
            return (
              <Reveal key={area.name} delay={i * 100}>
                <div className="h-full rounded-3xl border border-champagne/40 bg-card p-7 shadow-soft transition-transform duration-300 hover:-translate-y-1.5">
                  <Icon className="h-6 w-6 text-gold" />
                  <h2 className="mt-4 text-lg font-semibold text-forest-deep">
                    {area.name}
                  </h2>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {area.description}
                  </p>
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      <section className="bg-secondary/50 py-24">
        <div className="mx-auto max-w-6xl px-6">
          <SectionHeading eyebrow="Why us" title="Why Palm & Purity" />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {reasons.map((reason, i) => (
              <Reveal key={reason.name} delay={i * 80}>
                <div className="h-full rounded-3xl bg-card p-7 shadow-soft">
                  <span className="font-display text-sm font-semibold text-accent">
                    0{i + 1}
                  </span>
                  <h3 className="mt-3 text-lg font-semibold text-forest-deep">
                    {reason.name}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {reason.description}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-14 text-center">
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-semibold text-accent-foreground shadow-soft transition-transform duration-200 hover:-translate-y-0.5"
            >
              Get a Quote <ArrowRight className="h-4 w-4" />
            </Link>
          </Reveal>
        </div>
      </section>
    </>
  );
}