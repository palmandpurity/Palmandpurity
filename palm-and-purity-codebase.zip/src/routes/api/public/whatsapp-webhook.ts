import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";

/**
 * WhatsApp Cloud API webhook endpoint.
 *
 * GET  — Meta webhook verification handshake.
 *        Meta sends hub.mode=subscribe & hub.verify_token; we echo hub.challenge
 *        when the verify token matches WHATSAPP_VERIFY_TOKEN.
 *
 * POST — Inbound message + status events from Meta. The payload is signed with
 *        your App Secret (HMAC SHA-256) in the `x-hub-signature-256` header;
 *        we verify the signature before processing.
 *
 * URL:  https://<your-project>.lovable.app/api/public/whatsapp-webhook
 */
export const Route = createFileRoute("/api/public/whatsapp-webhook")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const mode = url.searchParams.get("hub.mode");
        const token = url.searchParams.get("hub.verify_token");
        const challenge = url.searchParams.get("hub.challenge");

        const verifyToken = process.env["WHATSAPP_VERIFY_TOKEN"];

        if (
          mode === "subscribe" &&
          !!token &&
          !!verifyToken &&
          timingSafeEqual(
            Buffer.from(token),
            Buffer.from(verifyToken),
          ) &&
          challenge
        ) {
          return new Response(challenge, {
            status: 200,
            headers: { "Content-Type": "text/plain" },
          });
        }

        return new Response("Forbidden", { status: 403 });
      },

      POST: async ({ request }) => {
        const appSecret = process.env["WHATSAPP_APP_SECRET"];
        const signatureHeader =
          request.headers.get("x-hub-signature-256") ?? "";

        if (!appSecret) {
          return new Response("Server not configured", { status: 500 });
        }

        const rawBody = await request.text();

        // Verify HMAC SHA-256 signature from Meta.
        const expected = createHmac("sha256", appSecret)
          .update(rawBody)
          .digest("hex");

        const signature = signatureHeader.replace(/^sha256=/, "");
        const valid =
          signature.length === expected.length &&
          timingSafeEqual(Buffer.from(signature), Buffer.from(expected));

        if (!valid) {
          return new Response("Invalid signature", { status: 401 });
        }

        try {
          const payload = JSON.parse(rawBody);

          // Meta sends an array of entries; each entry has changes with
          // messages (inbound) or statuses (delivered/read).
          if (payload?.entry) {
            for (const entry of payload.entry) {
              for (const change of entry.changes ?? []) {
                const messages = change.value?.messages;
                if (messages?.length) {
                  for (const message of messages) {
                    const from = message.from;
                    const text =
                      message.text?.body ??
                      message.button?.text ??
                      "(non-text message)";
                    console.log(
                      `[WhatsApp] Inbound from ${from}: ${text}`,
                    );
                  }
                }
              }
            }
          }
        } catch (err) {
          console.error("Failed to parse WhatsApp webhook payload:", err);
        }

        // Meta expects a 200 EVENT_RECEIVED acknowledgement.
        return new Response("EVENT_RECEIVED", { status: 200 });
      },
    },
  },
});
