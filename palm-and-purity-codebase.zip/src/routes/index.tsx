import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ChevronDown, Leaf, MapPin, Sprout } from "lucide-react";
import heroPalm from "@/assets/hero-palm.jpg";
import { Reveal } from "@/components/reveal";
import { SectionHeading, Stat } from "@/components/section";
import { farms, portfolio, reasons, investmentAreas, sustainabilityPillars, images } from "@/lib/site-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Palm & Purity — Growing the Future of Agriculture in Sierra Leone" },
      {
        name: "description",
        content:
          "Palm & Purity is a diversified Sierra Leonean agribusiness across crops, livestock, aquaculture and apiculture in Tihun, Bo and Masiaka.",
      },
      { property: "og:title", content: "Palm & Purity — Sierra Leone Agribusiness" },
      {
        property: "og:description",
        content:
          "Sustainable farming, food production, value addition and long-term agricultural investment in Sierra Leone.",
      },
    ],
    links: [{ rel: "canonical", href: "https://sierra-palm-web.lovable.app/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          name: "Palm & Purity",
          url: "https://sierra-palm-web.lovable.app/",
          email: "hello@palmandpurity.com",
          telephone: "+232 00 000 0000",
          address: {
            "@type": "PostalAddress",
            addressCountry: "SL",
            addressRegion: "Sierra Leone",
          },
          areaServed: "Sierra Leone",
          description:
            "Diversified Sierra Leonean agribusiness across crops, livestock, aquaculture and apiculture in Tihun, Bo and Masiaka.",
        }),
      },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <>
      <section className="relative isolate flex min-h-[92vh] items-center overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <img
            src={heroPalm}
            alt="Aerial view of a palm plantation in Sierra Leone at sunrise"
            width={1920}
            height={1080}
            className="hero-drift h-full w-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-forest-deep/90 via-forest-deep/65 to-forest-deep/25" />

        <div className="relative mx-auto w-full max-w-6xl px-6 py-28">
          <Reveal className="max-w-3xl">
            <p className="eyebrow text-accent">Sierra Leone Agribusiness</p>
            <h1 className="mt-6 text-4xl font-semibold leading-[1.06] text-primary-foreground sm:text-5xl lg:text-6xl">
              Palm &amp; Purity: Sustainable Agriculture &amp; Food Production in
              Sierra Leone
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-primary-foreground/85 sm:text-lg">
              Palm &amp; Purity is building a diversified agricultural enterprise
              focused on sustainable farming, food production, value addition and
              long-term growth across Sierra Leone.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link
                to="/farms"
                className="inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-semibold text-accent-foreground shadow-lift transition-transform duration-200 hover:-translate-y-0.5"
              >
                Explore Our Farms
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/40 px-7 py-3.5 text-sm font-semibold text-primary-foreground transition-colors duration-200 hover:bg-primary-foreground/10"
              >
                Get a Quote
              </Link>
            </div>
          </Reveal>
        </div>

        <div className="absolute inset-x-0 bottom-8 flex justify-center">
          <ChevronDown className="scroll-hint h-7 w-7 text-primary-foreground/80" />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-24">
        <SectionHeading
          eyebrow="Who we are"
          title="Building Agriculture for Tomorrow"
          intro="Palm & Purity is an integrated agribusiness with three complementary farms located in Tihun, Bo and Masiaka, creating a diversified agricultural portfolio across crops, livestock, aquaculture and apiculture."
        />
        <div className="mt-14 grid gap-6 sm:grid-cols-3">
          <Reveal delay={0}>
            <Stat value="3" label="Farming Locations" />
          </Reveal>
          <Reveal delay={120}>
            <Stat value="Multiple" label="Agricultural Activities" />
          </Reveal>
          <Reveal delay={240}>
            <Stat value="Sierra Leone" label="Our Home & Market" />
          </Reveal>
        </div>
      </section>

      <section className="bg-secondary/50 py-24">
        <div className="mx-auto grid max-w-6xl items-center gap-14 px-6 lg:grid-cols-2">
          <Reveal>
            <div className="overflow-hidden rounded-3xl shadow-lift">
              <img
                src={images.aboutFarm}
                alt="Farmer inspecting healthy crops on a Palm & Purity farm"
                width={1200}
                height={900}
                loading="lazy"
                className="h-full w-full object-cover"
              />
            </div>
          </Reveal>
          <Reveal delay={120}>
            <p className="eyebrow text-leaf">About Palm &amp; Purity</p>
            <h2 className="mt-4 text-3xl font-semibold text-forest-deep sm:text-4xl">
              An integrated agribusiness rooted in Sierra Leone
            </h2>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground">
              Our approach combines crop production, livestock, aquaculture and
              apiculture while creating opportunities for value addition,
              processing and future expansion.
            </p>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground">
              We are committed to developing productive farms that contribute to
              food security, employment, sustainable agriculture and economic
              growth.
            </p>
            <Link
              to="/about"
              className="mt-8 inline-flex items-center gap-2 font-semibold text-forest transition-colors hover:text-leaf"
            >
              Read our story <ArrowRight className="h-4 w-4" />
            </Link>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-24">
        <SectionHeading
          eyebrow="Our Farms"
          title="Three farms. One integrated model."
          intro="Each location contributes distinct strengths to a diversified agricultural portfolio."
        />
        <div className="mt-14 grid gap-8 md:grid-cols-3">
          {farms.map((farm, i) => (
            <Reveal key={farm.slug} delay={i * 120} as="article">
              <div className="group h-full overflow-hidden rounded-3xl border border-border/70 bg-card shadow-soft transition-all duration-300 hover:-translate-y-2 hover:shadow-lift">
                <div className="h-56 overflow-hidden">
                  <img
                    src={farm.image}
                    alt={farm.name}
                    width={1200}
                    height={900}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="p-7">
                  <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-leaf">
                    <MapPin className="h-3.5 w-3.5" /> Sierra Leone
                  </p>
                  <h3 className="mt-3 text-xl font-semibold text-forest-deep">
                    {farm.name}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {farm.description}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-12 text-center">
          <Link
            to="/agriculture"
            className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-soft transition-transform duration-200 hover:-translate-y-0.5"
          >
            Explore Our Agricultural Portfolio
            <ArrowRight className="h-4 w-4" />
          </Link>
        </Reveal>
      </section>

      <section className="bg-secondary/50 py-24">
        <div className="mx-auto max-w-6xl px-6">
          <SectionHeading
            eyebrow="Portfolio"
            title="Our Agricultural Portfolio"
            intro="Palm & Purity operates across multiple agricultural sectors, creating a diversified production model designed to improve resilience, productivity and long-term value."
          />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {portfolio.map((item, i) => (
              <Reveal key={item.name} delay={i * 90}>
                <div className="group relative h-72 overflow-hidden rounded-3xl shadow-soft">
                  <img
                    src={item.image}
                    alt={item.name}
                    width={1200}
                    height={900}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-forest-deep/90 via-forest-deep/25 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-6">
                    <h3 className="text-lg font-semibold text-primary-foreground">
                      {item.name}
                    </h3>
                    <p className="mt-2 max-h-0 overflow-hidden text-sm leading-relaxed text-primary-foreground/80 opacity-0 transition-all duration-500 group-hover:max-h-32 group-hover:opacity-100">
                      {item.description}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="relative isolate overflow-hidden py-28">
        <img
          src={images.sustainability}
          alt=""
          aria-hidden="true"
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-forest-deep/88" />
        <div className="relative mx-auto max-w-6xl px-6">
          <SectionHeading
            tone="dark"
            eyebrow="Sustainability"
            title="Farming Responsibly. Growing Sustainably."
            intro="Palm & Purity is committed to agricultural practices that protect natural resources while improving productivity and creating long-term value."
          />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {sustainabilityPillars.map((pillar, i) => (
              <Reveal key={pillar.name} delay={i * 90}>
                <div className="h-full rounded-3xl border border-primary-foreground/15 bg-primary-foreground/5 p-7 backdrop-blur-sm transition-colors duration-300 hover:border-accent/60">
                  <Leaf className="h-6 w-6 text-accent" />
                  <h3 className="mt-4 text-lg font-semibold text-primary-foreground">
                    {pillar.name}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-primary-foreground/75">
                    {pillar.description}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-24">
        <SectionHeading
          eyebrow="Investment"
          title="Investing in Agricultural Growth"
          intro="Palm & Purity's diversified agricultural model creates opportunities for value addition, processing, market development and long-term agricultural investment."
        />
        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {investmentAreas.map((area, i) => (
            <Reveal key={area.name} delay={i * 100}>
              <div className="h-full rounded-3xl border border-border/70 bg-card p-7 shadow-soft transition-transform duration-300 hover:-translate-y-1.5">
                <Sprout className="h-6 w-6 text-leaf" />
                <h3 className="mt-4 text-lg font-semibold text-forest-deep">
                  {area.name}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {area.description}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-12 text-center">
          <Link
            to="/investment"
            className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-soft transition-transform duration-200 hover:-translate-y-0.5"
          >
            Get a Quote
            <ArrowRight className="h-4 w-4" />
          </Link>
        </Reveal>
      </section>

      <section className="bg-secondary/50 py-24">
        <div className="mx-auto max-w-6xl px-6">
          <SectionHeading eyebrow="Why us" title="Why Palm & Purity" />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {reasons.map((reason, i) => (
              <Reveal key={reason.name} delay={i * 80}>
                <div className="h-full rounded-3xl bg-card p-7 shadow-soft">
                  <span className="font-display text-sm font-semibold text-accent">
                    0{i + 1}
                  </span>
                  <h3 className="mt-3 text-lg font-semibold text-forest-deep">
                    {reason.name}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {reason.description}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="relative isolate overflow-hidden">
        <img
          src={images.landscape}
          alt=""
          aria-hidden="true"
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-forest-deep/85" />
        <div className="relative mx-auto max-w-4xl px-6 py-24 text-center">
          <Reveal>
            <h2 className="text-3xl font-semibold text-primary-foreground sm:text-4xl">
              Let's Grow Together
            </h2>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-primary-foreground/80">
              Whether you are interested in agricultural partnerships,
              investment, business opportunities or learning more about Palm
              &amp; Purity, we would be happy to connect.
            </p>
            <Link
              to="/contact"
              className="mt-9 inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-semibold text-accent-foreground shadow-lift transition-transform duration-200 hover:-translate-y-0.5"
            >
              Contact Us <ArrowRight className="h-4 w-4" />
            </Link>
          </Reveal>
        </div>
      </section>
    </>
  );
}