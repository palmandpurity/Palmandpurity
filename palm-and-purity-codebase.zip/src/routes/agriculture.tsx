import { createFileRoute } from "@tanstack/react-router";
import { PageHero, SectionHeading } from "@/components/section";
import { Reveal } from "@/components/reveal";
import { portfolio, images } from "@/lib/site-data";

export const Route = createFileRoute("/agriculture")({
  head: () => ({
    meta: [
      { title: "Agricultural Portfolio — Crops, Livestock & Aquaculture | Palm & Purity" },
      {
        name: "description",
        content:
          "Palm & Purity's agricultural portfolio spans commercial crops, fruits and coconut, livestock, aquaculture and apiculture in Sierra Leone.",
      },
      { property: "og:title", content: "Our Agricultural Portfolio | Palm & Purity" },
      {
        property: "og:description",
        content:
          "A diversified production model designed to improve resilience, productivity and long-term value.",
      },
    ],
  }),
  component: AgriculturePage,
});

function AgriculturePage() {
  return (
    <>
      <PageHero
        eyebrow="Agriculture"
        title="Our Agricultural Portfolio"
        intro="Palm & Purity operates across multiple agricultural sectors, creating a diversified production model designed to improve resilience, productivity and long-term value."
        image={images.machinery}
      />

      <section className="mx-auto max-w-6xl px-6 py-24">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {portfolio.map((item, i) => (
            <Reveal key={item.name} delay={i * 90}>
              <div className="group h-full overflow-hidden rounded-3xl border border-border/70 bg-card shadow-soft transition-all duration-300 hover:-translate-y-2 hover:shadow-lift">
                <div className="h-56 overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.name}
                    width={1200}
                    height={900}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="p-7">
                  <h2 className="text-xl font-semibold text-forest-deep">
                    {item.name}
                  </h2>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {item.description}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-secondary/50 py-24">
        <div className="mx-auto max-w-6xl px-6">
          <SectionHeading
            eyebrow="Production model"
            title="From field to finished product"
            intro="Our diversified activities are designed to work together — crop residues, water systems, pollination and livestock all reinforce one another across the portfolio."
          />
        </div>
      </section>
    </>
  );
}