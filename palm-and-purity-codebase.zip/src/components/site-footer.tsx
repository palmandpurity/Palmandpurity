import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone } from "lucide-react";
import logo from "@/assets/logo.png.asset.json";
import { contactDetails } from "@/lib/site-data";

const quickLinks = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Farms", to: "/farms" },
  { label: "Agriculture", to: "/agriculture" },
  { label: "Sustainability", to: "/sustainability" },
  { label: "Investment", to: "/investment" },
  { label: "Contact", to: "/contact" },
] as const;

export function SiteFooter() {
  return (
    <footer className="bg-forest-deep text-primary-foreground">
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 md:grid-cols-3">
          <div>
            <div className="flex min-w-0 items-center gap-3">
              <img
                src={logo.url}
                alt="Palm & Purity logo"
                width={48}
                height={48}
                loading="lazy"
                className="h-12 w-12 shrink-0 rounded-full object-cover"
              />
              <span className="font-display text-xl font-semibold">
                Palm &amp; Purity
              </span>
            </div>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-primary-foreground/70">
              Growing the Future of Agriculture in Sierra Leone.
            </p>
            <div className="mt-6 flex gap-3">
              {[
                { Icon: Facebook, label: "Facebook" },
                { Icon: Instagram, label: "Instagram" },
                { Icon: Linkedin, label: "LinkedIn" },
              ].map(({ Icon, label }) => (
                <a
                  key={label}
                  href="#"
                  aria-label={label}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-primary-foreground/25 text-primary-foreground/80 transition-colors hover:border-champagne hover:text-champagne"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="eyebrow text-accent">Quick Links</h3>
            <ul className="mt-5 grid grid-cols-2 gap-2 text-sm">
              {quickLinks.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-primary-foreground/75 transition-colors hover:text-champagne"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="eyebrow text-accent">Contact</h3>
            <ul className="mt-5 space-y-3 text-sm text-primary-foreground/75">
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                <span>{contactDetails.location}</span>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                <a
                  href={`mailto:${contactDetails.email}`}
                  className="break-all hover:text-champagne"
                >
                  {contactDetails.email}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                <span>{contactDetails.phone}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 border-t border-primary-foreground/15 pt-6 text-center text-xs text-primary-foreground/60">
          © 2026 Palm &amp; Purity. All Rights Reserved.
        </div>
      </div>
    </footer>
  );
}