(() => {
  "use strict";

  const page = document.body.dataset.page || "home";
  const icon = (name, className = "icon") => `<svg class="${className}" aria-hidden="true"><use href="assets/icons.svg#${name}"></use></svg>`;
  const nav = [
    ["home", "Home", "index.html"],
    ["about", "About", "about.html"],
    ["farms", "Our Farms", "farms.html"],
    ["agriculture", "Agriculture", "agriculture.html"],
    ["sustainability", "Sustainability", "sustainability.html"],
    ["investment", "Investment", "investment.html"],
    ["gallery", "Gallery", "gallery.html"],
    ["contact", "Contact", "contact.html"],
  ];

  const navLinks = (mobile = false) => nav.map(([key, label, href]) =>
    `<a class="nav-link${page === key ? " active" : ""}" href="${href}"${page === key ? ' aria-current="page"' : ""}>${label}</a>`
  ).join("") + `<a class="quote-link" href="contact.html">Get a Quote</a>`;

  const headerTarget = document.querySelector("[data-site-header]");
  if (headerTarget) {
    headerTarget.innerHTML = `
      <header class="site-header">
        <div class="container-wide header-inner">
          <a class="brand" href="index.html" aria-label="Palm &amp; Purity home">
            <img src="assets/logo.png" width="48" height="48" alt="Palm &amp; Purity logo">
            <span><span class="brand-name">Palm &amp; Purity</span><span class="brand-tagline">Sierra Leone Agribusiness</span></span>
          </a>
          <nav class="desktop-nav" aria-label="Primary navigation">${navLinks()}</nav>
          <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="mobile-navigation" aria-label="Open menu">${icon("menu")}</button>
        </div>
        <div class="mobile-nav" id="mobile-navigation">
          <nav class="container-wide mobile-nav-inner" aria-label="Mobile navigation">${navLinks(true)}</nav>
        </div>
      </header>`;

    const header = headerTarget.querySelector(".site-header");
    const toggle = headerTarget.querySelector(".menu-toggle");
    const mobileNav = headerTarget.querySelector(".mobile-nav");
    const updateHeader = () => header.classList.toggle("is-scrolled", window.scrollY > 24);
    const closeMenu = () => {
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", "Open menu");
      toggle.innerHTML = icon("menu");
      mobileNav.classList.remove("open");
      header.classList.remove("is-open");
      document.body.classList.remove("menu-open");
    };
    toggle.addEventListener("click", () => {
      const isOpen = toggle.getAttribute("aria-expanded") === "true";
      if (isOpen) return closeMenu();
      toggle.setAttribute("aria-expanded", "true");
      toggle.setAttribute("aria-label", "Close menu");
      toggle.innerHTML = icon("close");
      mobileNav.classList.add("open");
      header.classList.add("is-open");
      document.body.classList.add("menu-open");
    });
    mobileNav.addEventListener("click", (event) => {
      if (event.target.closest("a")) closeMenu();
    });
    window.addEventListener("scroll", updateHeader, { passive: true });
    updateHeader();
  }

  const footerTarget = document.querySelector("[data-site-footer]");
  if (footerTarget) {
    footerTarget.innerHTML = `
      <footer class="site-footer">
        <div class="container-wide footer-grid">
          <div class="footer-brand">
            <a class="brand" href="index.html"><img src="assets/logo.png" width="48" height="48" loading="lazy" alt="Palm &amp; Purity logo"><span class="brand-name">Palm &amp; Purity</span></a>
            <p>Growing the Future of Agriculture in Sierra Leone.</p>
            <div class="social-row" aria-label="Social media channels">
              <span class="social-icon" title="Facebook">${icon("facebook")}</span>
              <span class="social-icon" title="Instagram">${icon("instagram")}</span>
              <span class="social-icon" title="LinkedIn">${icon("linkedin")}</span>
            </div>
          </div>
          <div>
            <h2 class="eyebrow footer-title">Quick Links</h2>
            <ul class="footer-links">${nav.slice(0, 6).map(([, label, href]) => `<li><a href="${href}">${label}</a></li>`).join("")}<li><a href="contact.html">Contact</a></li></ul>
          </div>
          <div>
            <h2 class="eyebrow footer-title">Contact</h2>
            <ul class="contact-list">
              <li>${icon("map-pin")}<span>Sierra Leone</span></li>
              <li>${icon("mail")}<a href="mailto:info@palmandpurity.com">info@palmandpurity.com</a></li>
              <li>${icon("phone")}<a href="tel:+23273391309">+232 73 391 309</a></li>
            </ul>
          </div>
        </div>
        <div class="container-wide copyright">© 2026 Palm &amp; Purity. All Rights Reserved.</div>
      </footer>`;
  }

  const whatsappTarget = document.querySelector("[data-whatsapp]");
  if (whatsappTarget) {
    whatsappTarget.innerHTML = `<a class="floating-whatsapp" href="https://wa.me/23273391309" target="_blank" rel="noopener noreferrer" aria-label="Chat with Palm &amp; Purity on WhatsApp">${icon("message")}<span>WhatsApp</span></a>`;
  }

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const reveals = document.querySelectorAll(".reveal");
  if (reduceMotion || !("IntersectionObserver" in window)) {
    reveals.forEach((element) => element.classList.add("is-visible"));
  } else {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { rootMargin: "0px 0px -10% 0px", threshold: 0.08 });
    reveals.forEach((element) => observer.observe(element));
  }

  const filterButtons = document.querySelectorAll("[data-gallery-filter]");
  const galleryItems = document.querySelectorAll("[data-gallery-category]");
  filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const category = button.dataset.galleryFilter;
      filterButtons.forEach((item) => {
        item.classList.toggle("active", item === button);
        item.setAttribute("aria-pressed", String(item === button));
      });
      galleryItems.forEach((item) => {
        item.hidden = category !== "All" && item.dataset.galleryCategory !== category;
      });
    });
  });

  const contactForm = document.querySelector("[data-contact-form]");
  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!contactForm.reportValidity()) return;
      const data = new FormData(contactForm);
      const lines = [
        "Hello Palm & Purity,",
        "",
        `Name: ${data.get("fullName") || ""}`,
        `Email: ${data.get("email") || ""}`,
        data.get("phone") ? `Phone: ${data.get("phone")}` : "",
        data.get("company") ? `Company / Organization: ${data.get("company")}` : "",
        `Subject: ${data.get("subject") || ""}`,
        "",
        String(data.get("message") || ""),
      ].filter(Boolean).join("\n");
      const url = `https://wa.me/23273391309?text=${encodeURIComponent(lines)}`;
      window.open(url, "_blank", "noopener,noreferrer");
    });
  }
})();
