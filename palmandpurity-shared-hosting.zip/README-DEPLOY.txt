PALM & PURITY — SHARED HOSTING DEPLOYMENT
=========================================

This folder is the complete static website. It does not require Node.js,
npm, Bun, React, a database, or a server process.

UPLOAD
------
1. Open your shared-hosting File Manager or connect by FTP/SFTP.
2. Open the domain's document root (usually public_html).
3. Upload the CONTENTS of this folder, including .htaccess and the assets folder.
4. Confirm that index.html is directly inside public_html.
5. Open the domain and test Home, Gallery, Contact, and the mobile menu.

CONTACT FORM
------------
The original React site used server-only WhatsApp Cloud API credentials.
A browser-only static site cannot keep those credentials secret. The static
form therefore prepares the visitor's message in WhatsApp, where the visitor
reviews it before sending. The destination number is +232 73 391 309.

If you later want silent server-side delivery, add a secure hosting-side PHP
or API endpoint. Never put WhatsApp access tokens in assets/site.js.

DOMAIN
------
sitemap.xml currently uses https://palmandpurity.com/. If your final domain
is different, replace that domain in sitemap.xml before launch.

CACHE
-----
After updating styles or JavaScript on a live host, clear the hosting/CDN cache
or rename the asset file so repeat visitors receive the new version.
